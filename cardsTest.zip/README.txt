To run the card game, it is preferable to place the input file
inside the same directory as the jar when running.
Otherwise, use the full file path. Input the number of players 
and file path when prompted. 

Exceptions are handeled if anything but postive integers are input. 
As such, the stack trace and or custom error messages may be 
displayed if letters/negative integers/ other illegal arguments 
are passed through the file.

Note that players will start from 0 with player 0 retaining
cards numbered 0, player 1 will retain cards numbered 1, and
so on so forth.

Player logs will be generated in the same directory as the jar.